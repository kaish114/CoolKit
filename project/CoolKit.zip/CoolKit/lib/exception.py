class UserNotAvailable(Exception):
    pass

class LoginFalied(Exception):
    pass

class NotLoggedIn(Exception):
    pass

class InvalidProblem(Exception):
    pass
